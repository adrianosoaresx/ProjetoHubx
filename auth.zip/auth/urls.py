# autentication /urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.login, name='login'),
    path('password_reset/', views.password_reset, name='password_reset'),

    path('token/', views.token, name='token'),
    path('nome/', views.nome, name='nome'),
    path('email/', views.email, name='email'),
    path('usuario/', views.usuario, name='usuario'),
    path('senha/', views.senha, name='senha'),
    path('termos/', views.termos, name='termos'),
    path('onboarding/', views.onboarding, name='onboarding'),
    path('foto/', views.foto, name='foto'),





]
